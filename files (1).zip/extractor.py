"""
Extraction Engine
Handles discovery, unzipping, PFG execution, XML parsing, and library storage.
"""

import json
import logging
import os
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path
from typing import Optional

from app.config import Config
from app.parser import PanXMLParser
from app.xlsx_reader import read_data_xlsx

logger = logging.getLogger(__name__)


class ExtractionEngine:
    def __init__(self, config: Config):
        self.cfg = config

    # ─── Discovery ────────────────────────────────────────────────────────────

    def discover_variants(self) -> dict:
        """Scan upload dirs and return structured list of all variants."""
        result = {}
        if not self.cfg.upload_root.exists():
            logger.warning(f"Upload root not found: {self.cfg.upload_root}")
            return result

        for folder_name, cat_key in self.cfg.CATEGORIES.items():
            cat_dir = self.cfg.upload_root / folder_name
            if not cat_dir.exists():
                continue

            # Load _Data.xlsx metadata if present
            xlsx_meta = {}
            for xlsx in cat_dir.glob("*_Data.xlsx"):
                xlsx_meta = read_data_xlsx(xlsx)
                break

            variants = []
            seen = set()

            # Find .panx files (ZIP archives)
            for panx in sorted(cat_dir.rglob("*.panx")):
                vid = panx.stem
                if vid in seen:
                    continue
                seen.add(vid)
                lib_entry = self._library_path(cat_key, vid)
                variants.append({
                    "id": vid,
                    "format": "panx",
                    "source": str(panx.relative_to(self.cfg.upload_root)),
                    "processed": lib_entry.exists(),
                    "description": xlsx_meta.get(vid, {}).get("description", ""),
                    "tags": xlsx_meta.get(vid, {}).get("tags", []),
                })

            # Find loose .pan files (not inside .panx)
            for pan in sorted(cat_dir.rglob("*.pan")):
                vid = pan.stem
                if vid in seen:
                    continue
                seen.add(vid)
                bas_file = pan.with_suffix(".bas")
                lib_entry = self._library_path(cat_key, vid)
                variants.append({
                    "id": vid,
                    "format": "pan",
                    "source": str(pan.relative_to(self.cfg.upload_root)),
                    "has_bas": bas_file.exists(),
                    "processed": lib_entry.exists(),
                    "description": xlsx_meta.get(vid, {}).get("description", ""),
                    "tags": xlsx_meta.get(vid, {}).get("tags", []),
                })

            if variants:
                result[cat_key] = variants

        return result

    # ─── Processing ───────────────────────────────────────────────────────────

    def process_variant(self, category: str, item: dict) -> dict:
        """Full extraction pipeline for one variant. Returns extracted data."""
        vid = item["id"]
        fmt = item["format"]
        folder_name = self._cat_folder(category)
        cat_dir = self.cfg.upload_root / folder_name

        with tempfile.TemporaryDirectory(prefix=f"rc_{vid}_") as tmp:
            tmp = Path(tmp)

            if fmt == "panx":
                # Find source file
                panx_path = next(cat_dir.rglob(f"{vid}.panx"), None)
                if not panx_path:
                    raise FileNotFoundError(f"Cannot find {vid}.panx in {cat_dir}")
                pan_path, meta, graphics = self._unzip_panx(panx_path, tmp, category, vid)
            else:
                pan_path = next(cat_dir.rglob(f"{vid}.pan"), None)
                if not pan_path:
                    raise FileNotFoundError(f"Cannot find {vid}.pan in {cat_dir}")
                meta = {}
                graphics = []

            # Run PFG to produce sidecar XML
            xml_path = self._run_pfg(pan_path, tmp, vid)

            # Parse XML
            parsed = PanXMLParser.parse(xml_path)

            # Read loose .bas if present
            bas_path = pan_path.with_suffix(".bas")
            if not bas_path.exists():
                bas_path = self.cfg.upload_root / folder_name / f"{vid}.bas"
            bas_source = bas_path.read_text(errors="replace") if bas_path.exists() else None

            # Build library record
            record = {
                "id": vid,
                "category": category,
                "format": fmt,
                "meta": meta,
                "graphics": graphics,
                "objects": parsed,
                "bas_source": bas_source,
                "counts": self._count_objects(parsed),
            }

            # Save to library
            self._save_library_entry(category, vid, record)
            return record

    # ─── PANX Unzip ───────────────────────────────────────────────────────────

    def _unzip_panx(self, panx_path: Path, tmp: Path, category: str, vid: str):
        """Extract .panx ZIP: returns (pan_path, meta_dict, graphics_list)."""
        extract_dir = tmp / "panx_contents"
        extract_dir.mkdir()

        with zipfile.ZipFile(panx_path, "r") as z:
            z.extractall(extract_dir)

        pan_files = list(extract_dir.rglob("*.pan"))
        if not pan_files:
            raise ValueError(f"No .pan inside {panx_path.name}")
        pan_path = pan_files[0]

        meta = {}
        meta_file = extract_dir / "meta.json"
        if meta_file.exists():
            try:
                meta = json.loads(meta_file.read_text())
            except Exception:
                pass

        # Copy graphics to assets folder
        graphics = []
        asset_dir = self.cfg.assets_root / category / vid
        asset_dir.mkdir(parents=True, exist_ok=True)
        for gfx in extract_dir.rglob("*"):
            if gfx.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".svg", ".bmp"}:
                dest = asset_dir / gfx.name
                shutil.copy2(gfx, dest)
                graphics.append(gfx.name)

        return pan_path, meta, graphics

    # ─── PFG Runner ───────────────────────────────────────────────────────────

    def _run_pfg(self, pan_path: Path, tmp: Path, vid: str) -> Path:
        """Run PanelFileGenerator.exe under Wine. Returns path to output XML."""
        out_pan = tmp / f"{vid}_out.pan"
        log_txt = tmp / f"{vid}_pfg.log"
        # PFG writes sidecar XML alongside -o path as <basename>.xml
        xml_out = tmp / f"{vid}_out.xml"

        cmd = [
            self.cfg.wine_bin,
            str(self.cfg.pfg_exe),
            "-i", str(pan_path),
            "-o", str(out_pan),
            "-c", str(self.cfg.blank_xml),
            "-f", str(log_txt),
        ]

        logger.info(f"Running PFG: {' '.join(cmd)}")

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.cfg.pfg_timeout,
                env={**os.environ, "WINEDEBUG": "-all"},
            )
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"PFG timed out after {self.cfg.pfg_timeout}s for {vid}")

        if result.returncode != 0:
            log_content = log_txt.read_text(errors="replace") if log_txt.exists() else "(no log)"
            raise RuntimeError(
                f"PFG failed (exit {result.returncode}) for {vid}.\n"
                f"stderr: {result.stderr[:500]}\nlog: {log_content[:500]}"
            )

        # Find the XML — PFG may name it differently; search around output
        candidates = list(tmp.glob("*.xml"))
        if not candidates:
            raise FileNotFoundError(f"PFG produced no XML file in {tmp} for {vid}")

        # Prefer one matching vid name
        for c in candidates:
            if vid.lower() in c.stem.lower():
                return c
        return candidates[0]

    # ─── Library Storage ──────────────────────────────────────────────────────

    def _library_path(self, category: str, vid: str) -> Path:
        return self.cfg.library_root / category / f"{vid}.json"

    def _save_library_entry(self, category: str, vid: str, record: dict):
        p = self._library_path(category, vid)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(record, indent=2))

    def load_library_entry(self, category: str, vid: str) -> Optional[dict]:
        p = self._library_path(category, vid)
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text())
        except Exception:
            return None

    def library_summary(self) -> dict:
        """Return all processed variants with counts — lightweight."""
        summary = {}
        if not self.cfg.library_root.exists():
            return summary
        for cat_dir in sorted(self.cfg.library_root.iterdir()):
            if not cat_dir.is_dir():
                continue
            variants = []
            for jf in sorted(cat_dir.glob("*.json")):
                try:
                    data = json.loads(jf.read_text())
                    variants.append({
                        "id": data.get("id", jf.stem),
                        "category": data.get("category", cat_dir.name),
                        "format": data.get("format"),
                        "counts": data.get("counts", {}),
                        "meta": data.get("meta", {}),
                        "description": data.get("meta", {}).get("description", ""),
                    })
                except Exception:
                    pass
            if variants:
                summary[cat_dir.name] = variants
        return summary

    def full_library_export(self) -> dict:
        """Full JSON export of entire library."""
        export = {}
        if not self.cfg.library_root.exists():
            return export
        for cat_dir in sorted(self.cfg.library_root.iterdir()):
            if not cat_dir.is_dir():
                continue
            export[cat_dir.name] = {}
            for jf in sorted(cat_dir.glob("*.json")):
                try:
                    data = json.loads(jf.read_text())
                    export[cat_dir.name][jf.stem] = data
                except Exception:
                    pass
        return export

    # ─── Helpers ──────────────────────────────────────────────────────────────

    def _cat_folder(self, cat_key: str) -> str:
        inv = {v: k for k, v in self.cfg.CATEGORIES.items()}
        return inv.get(cat_key, cat_key)

    def _count_objects(self, parsed: dict) -> dict:
        counts = {}
        for key, val in parsed.items():
            if isinstance(val, list):
                counts[key] = len(val)
        return counts
