#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Reliable Controls Extraction Tool — Install Script
# Run as root: sudo bash install.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

APP_DIR="/opt/reliable-extractor"
SERVICE_NAME="rc-extractor"
PORT=8085

echo "═══════════════════════════════════════════════"
echo "  RC Extractor Install"
echo "═══════════════════════════════════════════════"

# ── 1. Copy files ──────────────────────────────────
echo "[1/5] Copying application files to $APP_DIR…"
mkdir -p "$APP_DIR"
cp -r . "$APP_DIR/"
chmod -R 755 "$APP_DIR"

# ── 2. Python venv ─────────────────────────────────
echo "[2/5] Creating Python virtual environment…"
python3 -m venv "$APP_DIR/venv"
"$APP_DIR/venv/bin/pip" install --upgrade pip -q
"$APP_DIR/venv/bin/pip" install -r "$APP_DIR/requirements.txt" -q
echo "      Dependencies installed."

# ── 3. Shared directories ──────────────────────────
echo "[3/5] Creating shared file directories…"
mkdir -p \
  /srv/dfa/shared/files/vendors/reliable/uploads \
  /srv/dfa/shared/files/vendors/reliable/library \
  /srv/dfa/shared/files/vendors/reliable/assets

# Create blank XML
cat > /srv/dfa/shared/files/vendors/reliable/BlankXML.xml <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<points></points>
EOF

# Set ownership
chown -R www-data:www-data /srv/dfa/shared/files/vendors/reliable
echo "      Directories ready."

# ── 4. Systemd service ─────────────────────────────
echo "[4/5] Installing systemd service…"
cp "$APP_DIR/rc-extractor.service" "/etc/systemd/system/${SERVICE_NAME}.service"
systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"
echo "      Service started."

# ── 5. Status ──────────────────────────────────────
echo "[5/5] Verifying…"
sleep 2
if systemctl is-active --quiet "$SERVICE_NAME"; then
  echo ""
  echo "  ✓ RC Extractor is running on http://localhost:$PORT"
  echo "  ✓ API docs: http://localhost:$PORT/api/docs"
  echo "  ✓ Service: $SERVICE_NAME (systemd)"
  echo ""
  echo "  DFA Integration:"
  echo "    Base URL:    http://localhost:$PORT"
  echo "    Library API: http://localhost:$PORT/api/library"
  echo "    Compare API: http://localhost:$PORT/api/library/compare?a=VAV/RC-VAV-01&b=VAV/RC-VAV-02"
  echo "    Export API:  http://localhost:$PORT/api/library/export"
else
  echo "  ✗ Service failed to start. Check: journalctl -u $SERVICE_NAME -f"
  exit 1
fi
