# RC Extractor — DFA Integration Reference
**Base URL:** `http://localhost:8085`  
**Service:** `rc-extractor` (systemd)  
**Port:** `8085` (configurable in `rc-extractor.service`)  
**Auto-docs:** `http://localhost:8085/api/docs`

---

## Endpoints

### GET `/api/variants`
Discover all uploaded variants (before processing).

```json
{
  "VAV": [
    {
      "id": "RC-VAV-01",
      "format": "panx",
      "source": "RC VAV Programming/RC-VAV-01.panx",
      "processed": true,
      "description": "Single Duct VAV with Reheat",
      "tags": ["heating", "cooling"]
    }
  ],
  "RTU": [ ... ]
}
```

---

### POST `/api/process?category=VAV`
Trigger extraction pipeline. `category` is optional — omit to process all.

```json
{ "job_id": "a3f8b2c1", "message": "Extraction started" }
```

---

### GET `/api/process/{job_id}/status`
Poll job status.

```json
{
  "status": "running",   // queued | running | done | error
  "progress": 12,
  "total": 34,
  "current": "VAV/RC-VAV-12",
  "done": ["VAV/RC-VAV-01", ...],
  "errors": [{ "variant": "RTU/RC-RTU-05", "error": "PFG timeout" }]
}
```

---

### GET `/api/process/{job_id}/stream`
SSE stream — same payload as `/status`, pushed every second.

---

### GET `/api/library`
**Main dashboard feed.** All processed variants with object counts. Lightweight.

```json
{
  "VAV": [
    {
      "id": "RC-VAV-01",
      "category": "VAV",
      "format": "panx",
      "counts": {
        "AI": 8, "AO": 4, "AV": 22,
        "BI": 6, "BO": 3, "BV": 14,
        "MO": 2, "MV": 5,
        "PROGRAM": 3, "LOOP": 2,
        "TREND": 4, "SCHEDULE": 1
      }
    }
  ]
}
```

---

### GET `/api/variants/{category}/{variant_id}`
Full extracted data for one variant.

```json
{
  "id": "RC-VAV-01",
  "category": "VAV",
  "format": "panx",
  "meta": { "description": "...", "version": "..." },
  "graphics": ["floor_plan.png"],
  "counts": { "AI": 8, ... },
  "objects": {
    "AI": [
      {
        "type": "AI",
        "instance": "1",
        "name": "Space Temp",
        "unit": "degF",
        "range_min": "40",
        "range_max": "100",
        "cov": "0.5",
        "states": []
      }
    ],
    "PROGRAM": [
      {
        "instance": "1",
        "name": "Main Control",
        "code": "' Control-BASIC source...\n..."
      }
    ],
    "LOOP": [
      {
        "instance": "1",
        "name": "Cooling Loop",
        "kp": "2.5",
        "ti": "300",
        "td": "0",
        "action": "DIRECT"
      }
    ],
    "TREND": [ ... ],
    "SCHEDULE": [ ... ]
  },
  "bas_source": "' Full Control-BASIC source if loose .bas present\n..."
}
```

---

### GET `/api/library/compare?a=VAV/RC-VAV-01&b=VAV/RC-VAV-02`
Side-by-side comparison. Returns full data for both variants.

```json
{ "a": { ...full variant data... }, "b": { ...full variant data... } }
```

---

### GET `/api/library/export`
Full library as single JSON bundle — use to import all data into DFA at once.

```json
{
  "VAV": { "RC-VAV-01": { ...full... }, "RC-VAV-02": { ... } },
  "RTU": { ... }
}
```

---

## DFA Wiring

### Nav Link
Add to your DFA nav (React):
```jsx
<a href="http://localhost:8085" target="_blank" rel="noopener">
  RC Library
</a>
```

### Iframe Embed (optional)
```jsx
<iframe
  src="http://localhost:8085"
  style={{ width: '100%', height: '100%', border: 'none' }}
  title="RC Extractor"
/>
```

### Fetch Library Data from DFA
```javascript
// Get all processed variants with counts
const library = await fetch('http://localhost:8085/api/library').then(r => r.json());

// Get specific variant full data
const vav01 = await fetch('http://localhost:8085/api/variants/VAV/RC-VAV-01').then(r => r.json());

// Trigger extraction from DFA
const job = await fetch('http://localhost:8085/api/process', { method: 'POST' }).then(r => r.json());
```

---

## Service Management
```bash
sudo systemctl start rc-extractor
sudo systemctl stop rc-extractor
sudo systemctl restart rc-extractor
sudo journalctl -u rc-extractor -f    # live logs
```

## File Paths
| Purpose | Path |
|---|---|
| Upload root | `/srv/dfa/shared/files/vendors/reliable/uploads/` |
| Library JSON | `/srv/dfa/shared/files/vendors/reliable/library/` |
| Assets | `/srv/dfa/shared/files/vendors/reliable/assets/` |
| Blank XML | `/srv/dfa/shared/files/vendors/reliable/BlankXML.xml` |
| App install | `/opt/reliable-extractor/` |
| Service unit | `/etc/systemd/system/rc-extractor.service` |
